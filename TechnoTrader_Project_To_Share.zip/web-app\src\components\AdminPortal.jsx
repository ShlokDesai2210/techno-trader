import React, { useState, useEffect } from 'react';
import { ref, onValue, update, push } from 'firebase/database';
import { db } from '../firebase';
import { AlertTriangle, TrendingUp, PackageSearch, Database, ShieldAlert } from 'lucide-react';

const suppliers = [
  { id: 0, name: "Alpha Tech", rateMultiplier: 0.60 },
  { id: 1, name: "Beta Corp", rateMultiplier: 0.55 },
  { id: 2, name: "Gamma Sol", rateMultiplier: 0.62 }
];

const AdminPortal = () => {
  const [isAuth, setIsAuth] = useState(false);
  const [authForm, setAuthForm] = useState({ id: '', pass: '' });
  
  const [inventory, setInventory] = useState([]);
  const [ledger, setLedger] = useState([]);
  
  // Split Restock Modal State
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [totalNeeded, setTotalNeeded] = useState(0);
  const [splitQty, setSplitQty] = useState({ 0: 0, 1: 0, 2: 0 });

  useEffect(() => {
    if (!isAuth) return;
    
    // Listen to Inventory
    onValue(ref(db, 'inventory'), (snapshot) => {
      const data = snapshot.val();
      if (data) setInventory(Object.values(data));
    });

    // Listen to Ledger
    onValue(ref(db, 'ledger'), (snapshot) => {
      const data = snapshot.val();
      if (data) setLedger(Object.values(data).reverse()); // newest first
    });
  }, [isAuth]);

  const handleLogin = (e) => {
    e.preventDefault();
    if (authForm.id === "admin" && authForm.pass === "1234") {
      setIsAuth(true);
    } else {
      alert("Invalid Credentials!");
    }
  };

  // derived ledger stats
  const totalSales = ledger.filter(t => t.type === 'CREDIT').reduce((sum, t) => sum + t.amount, 0);
  const totalExpense = ledger.filter(t => t.type === 'DEBIT').reduce((sum, t) => sum + t.amount, 0);
  const netProfit = totalSales - totalExpense;

  const lowStockItems = inventory.filter(p => p.stock < 5);

  const startRestock = (product) => {
    setSelectedProduct(product);
    setTotalNeeded(10); // default
    setSplitQty({ 0: 0, 1: 0, 2: 0 });
  };

  const handleSplitChange = (supId, val) => {
    setSplitQty(prev => ({ ...prev, [supId]: parseInt(val) || 0 }));
  };

  const confirmRestock = async () => {
    const sum = splitQty[0] + splitQty[1] + splitQty[2];
    if (sum !== totalNeeded) {
      return alert(`Quantities must add up to exactly ${totalNeeded}. Currently at ${sum}`);
    }

    try {
      // Process Restock
      const newStock = selectedProduct.stock + totalNeeded;
      await update(ref(db), { [`inventory/${selectedProduct.id}/stock`]: newStock });

      // Create Ledger Entries (Debits)
      for (const sup of suppliers) {
        const qty = splitQty[sup.id];
        if (qty > 0) {
          const rate = selectedProduct.price * sup.rateMultiplier;
          const cost = qty * rate;
          await push(ref(db, 'ledger'), {
            type: "DEBIT",
            desc: `Stock [${selectedProduct.name}]: ${sup.name}`,
            amount: cost,
            qty: qty,
            unitPrice: rate,
            timestamp: new Date().toISOString()
          });
        }
      }
      
      alert("Restock Successful & Ledger Updated!");
      setSelectedProduct(null);
    } catch (e) {
      alert("Error: " + e.message);
    }
  };

  if (!isAuth) {
    return (
      <div className="flex items-center justify-center min-h-[70vh]">
        <form onSubmit={handleLogin} className="glass-card w-96 p-8 animate-fade-in">
          <div className="text-center mb-6 text-primary">
            <ShieldAlert size={48} className="mx-auto mb-4" />
            <h2 className="mb-2">Admin Portal</h2>
            <p className="text-sm">Secure Entry Required</p>
          </div>
          <div className="form-group">
            <label className="form-label">Admin ID</label>
            <input type="text" className="form-input" value={authForm.id} onChange={e => setAuthForm({...authForm, id: e.target.value})} autoFocus />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input type="password" className="form-input" value={authForm.pass} onChange={e => setAuthForm({...authForm, pass: e.target.value})} />
          </div>
          <button type="submit" className="btn btn-primary w-full mt-4">Login</button>
        </form>
      </div>
    );
  }

  return (
    <div className="main-content animate-fade-in">
      
      {/* Dashboard Top KPIs */}
      <h2 className="mb-6 flex items-center gap-3"><TrendingUp/> MoneyBank Financials</h2>
      <div className="grid-cols-3 mb-8">
        <div className="glass-card border-l-4 border-l-success">
          <h4 className="text-secondary mb-2 uppercase text-sm tracking-wider">Total Sales (Income)</h4>
          <span className="text-3xl font-bold text-success">Rs. {totalSales.toFixed(2)}</span>
        </div>
        <div className="glass-card border-l-4 border-l-danger">
          <h4 className="text-secondary mb-2 uppercase text-sm tracking-wider">Total Stock (Expense)</h4>
          <span className="text-3xl font-bold text-danger">Rs. {totalExpense.toFixed(2)}</span>
        </div>
        <div className={`glass-card border-l-4 ${netProfit >= 0 ? 'border-l-primary' : 'border-l-danger'}`}>
          <h4 className="text-secondary mb-2 uppercase text-sm tracking-wider">Net {netProfit >= 0 ? 'Profit' : 'Loss'}</h4>
          <span className={`text-3xl font-bold ${netProfit >= 0 ? 'text-primary' : 'text-danger'}`}>Rs. {Math.abs(netProfit).toFixed(2)}</span>
        </div>
      </div>

      <div className="grid-cols-2">
        {/* Left: Low Stock Alerts & Inventory */}
        <div>
          <div className="glass-card mb-6">
            <h3 className="flex items-center gap-2 mb-4 text-warning"><AlertTriangle/> Low Stock Alerts (&lt; 5)</h3>
            {lowStockItems.length === 0 ? (
              <p className="text-success p-4 bg-emerald-900 bg-opacity-20 rounded-lg">All items are well stocked!</p>
            ) : (
              <div className="space-y-4">
                {lowStockItems.map(item => (
                  <div key={item.id} className="flex justify-between items-center p-3 bg-slate-800 rounded-lg border border-red-500 border-opacity-30">
                    <div>
                      <span className="font-bold">{item.name}</span>
                      <p className="text-sm text-secondary">Only {item.stock} left in stock</p>
                    </div>
                    <button className="btn btn-outline text-sm" onClick={() => startRestock(item)}>RESTOCK</button>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div className="glass-card overflow-hidden">
             <h3 className="flex items-center gap-2 mb-2 p-4 pb-0"><PackageSearch/> Full Inventory</h3>
             <div className="max-h-96 overflow-y-auto w-full">
               <table>
                 <thead>
                   <tr>
                     <th>ID</th>
                     <th>Product</th>
                     <th>Stock</th>
                     <th>Action</th>
                   </tr>
                 </thead>
                 <tbody>
                   {inventory.map(item => (
                     <tr key={item.id}>
                       <td>{item.id}</td>
                       <td>{item.name}</td>
                       <td><span className={`badge ${item.stock < 5 ? 'badge-danger' : 'badge-success'}`}>{item.stock}</span></td>
                       <td><button className="text-primary hover:underline text-sm font-medium" onClick={() => startRestock(item)}>Restock</button></td>
                     </tr>
                   ))}
                 </tbody>
               </table>
             </div>
          </div>
        </div>

        {/* Right: Split Restock & Ledger View */}
        <div>
          {selectedProduct && (
            <div className="glass-card mb-6 border-primary receipt-modal">
              <h3 className="text-primary mb-4">Split Restock: {selectedProduct.name}</h3>
              <p className="text-sm text-secondary mb-4">Base Retail: Rs. {selectedProduct.price}</p>
              
              <div className="flex gap-4 mb-6 items-center">
                <label className="font-medium whitespace-nowrap">Total Required Qty:</label>
                <input type="number" min="1" className="form-input" value={totalNeeded} onChange={(e) => setTotalNeeded(parseInt(e.target.value) || 0)} />
              </div>
              
              <h4 className="text-sm mb-3">Supplier Quotation Split:</h4>
              <div className="space-y-3 mb-6">
                {suppliers.map(sup => (
                  <div key={sup.id} className="flex items-center justify-between p-3 bg-slate-800 rounded">
                    <div>
                      <span className="font-medium block">{sup.name}</span>
                      <span className="text-xs text-secondary">Rate: Rs. {(selectedProduct.price * sup.rateMultiplier).toFixed(2)}</span>
                    </div>
                    <div className="w-24">
                       <input type="number" min="0" className="form-input text-center py-1" value={splitQty[sup.id]} onChange={e => handleSplitChange(sup.id, e.target.value)} />
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="flex justify-between items-center pt-4 border-t border-gray-700">
                <span className="text-sm">Assigned: {splitQty[0] + splitQty[1] + splitQty[2]} / {totalNeeded}</span>
                <div className="flex gap-2">
                  <button className="btn btn-outline" onClick={() => setSelectedProduct(null)}>Cancel</button>
                  <button className="btn btn-primary" onClick={confirmRestock}>Confirm Restock</button>
                </div>
              </div>
            </div>
          )}

          <div className="glass-card">
            <h3 className="flex items-center gap-2 mb-4"><Database/> Deep Ledger Transactions</h3>
            <div className="max-h-[500px] overflow-y-auto pr-2">
              {ledger.length === 0 ? <p className="text-secondary p-4 text-center">No transactions yet.</p> : (
                <div className="space-y-3">
                  {ledger.map((t, idx) => (
                    <div key={idx} className={`p-3 rounded-lg border-l-4 ${t.type === 'CREDIT' ? 'bg-emerald-900 bg-opacity-10 border-success' : 'bg-red-900 bg-opacity-10 border-danger'}`}>
                      <div className="flex justify-between mb-1">
                        <span className={`text-xs font-bold px-2 py-0.5 rounded ${t.type === 'CREDIT' ? 'bg-emerald-900 text-emerald-300' : 'bg-red-900 text-red-300'}`}>{t.type}</span>
                        <span className="text-xs text-secondary">{new Date(t.timestamp).toLocaleString()}</span>
                      </div>
                      <p className="font-medium text-sm my-2">{t.desc}</p>
                      <div className="flex justify-between text-xs text-secondary border-t border-gray-700 border-opacity-50 pt-2 mt-2">
                        <span>Qty: {t.qty} @ Rs.{t.unitPrice}</span>
                        <span className="font-bold">Rs. {t.amount.toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default AdminPortal;
