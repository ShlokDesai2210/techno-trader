import { ref, set } from "firebase/database";
import { db } from "../firebase";

// Database Seed Details based on the exact SRS details
// Inventory Array (Fixed Size: 5 Products)
// new Product(101, "Smart Watch", 2500, 10, false);
// new Product(102, "Headphones", 1500, 20, false);
// new Product(103, "Smartphone", 18000, 8, false);
// new Product(104, "LED TV 55\"", 45000, 5, true);
// new Product(105, "Gaming PC", 65000, 3, true);

export const seedDatabase = async () => {
  console.log("Seeding initial database...");
  
  const inventoryRef = ref(db, 'inventory');
  await set(inventoryRef, {
    "101": { id: 101, name: "Smart Watch", price: 2500, stock: 10, isLargeItem: false, category: "Wearables" },
    "102": { id: 102, name: "Headphones", price: 1500, stock: 20, isLargeItem: false, category: "Audio" },
    "103": { id: 103, name: "Smartphone", price: 18000, stock: 8, isLargeItem: false, category: "Mobile" },
    "104": { id: 104, name: "LED TV 55\"", price: 45000, stock: 5, isLargeItem: true, category: "Entertainment" },
    "105": { id: 105, name: "Gaming PC", price: 65000, stock: 3, isLargeItem: true, category: "Computers" }
  });

  const ledgerRef = ref(db, 'ledger');
  await set(ledgerRef, []); // Empty array
  
  const ordersRef = ref(db, 'orders');
  await set(ordersRef, {});

  console.log("Database seeded successfully!");
};
