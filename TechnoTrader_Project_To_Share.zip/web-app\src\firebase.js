import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA-eSTduF_Dzl2XkhjykTcIj413B9BwW4Q",
  authDomain: "techno-trader-37ff8.firebaseapp.com",
  databaseURL: "https://techno-trader-37ff8-default-rtdb.firebaseio.com",
  projectId: "techno-trader-37ff8",
  storageBucket: "techno-trader-37ff8.firebasestorage.app",
  messagingSenderId: "562909057377",
  appId: "1:562909057377:web:22ed8d09fa3c1203aef520"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
