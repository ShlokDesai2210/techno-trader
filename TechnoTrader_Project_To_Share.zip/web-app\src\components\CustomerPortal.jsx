import React, { useState, useEffect } from 'react';
import { ref, onValue, update, push, get } from 'firebase/database';
import { db } from '../firebase';
import { ShoppingCart, Package, Truck, ShieldCheck, User } from 'lucide-react';

const CustomerPortal = () => {
  const [inventory, setInventory] = useState([]);
  const [cart, setCart] = useState([]);
  const [customerInfo, setCustomerInfo] = useState({ name: '', mobile: '', address: '' });
  const [showInvoice, setShowInvoice] = useState(false);
  const [invoiceData, setInvoiceData] = useState(null);

  useEffect(() => {
    const invRef = ref(db, 'inventory');
    onValue(invRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        setInventory(Object.values(data));
      }
    });
  }, []);

  const addToCart = (product) => {
    if (product.stock <= 0) return alert("Out of stock!");
    
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        if (existing.qty >= product.stock) {
          alert("Cannot exceed available stock!");
          return prev;
        }
        return prev.map(item => item.id === product.id ? { ...item, qty: item.qty + 1 } : item);
      }
      return [...prev, { ...product, qty: 1 }];
    });
  };

  const hasLargeItems = cart.some(item => item.isLargeItem);
  const vehicle = hasLargeItems ? "Van" : "Bike";
  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const deliveryCharge = (vehicle === "Van" && !hasLargeItems) ? 200 : (cart.length > 0 ? (vehicle === "Van" ? 200 : 0) : 0); // Simplified logic
  const fastDeliveryCharge = 0; // Keeping it simple for UI, add checkbox if needed
  const gst = cartTotal * 0.18;
  const grandTotal = cartTotal + gst + deliveryCharge + fastDeliveryCharge;

  const handleCheckout = async () => {
    if (cart.length === 0) return alert("Cart is empty");
    if (customerInfo.mobile.length !== 10) return alert("Mobile must be exactly 10 digits");
    if (!customerInfo.name || !customerInfo.address) return alert("Please fill all details");

    const orderId = `${customerInfo.name.charAt(0).toUpperCase()}-${customerInfo.mobile.slice(-4)}`;
    
    // Process Transaction
    const updates = {};
    const ledgerEntries = [];
    
    cart.forEach(item => {
      // 1. Decrease Stock
      // Note: In real production app, use transaction to avoid race conditions
      const newStock = inventory.find(i => i.id === item.id).stock - item.qty;
      updates[`inventory/${item.id}/stock`] = newStock;
      
      // 2. Add to Ledger
      ledgerEntries.push({
        type: "CREDIT",
        desc: `Sale [${orderId}]: ${item.name}`,
        amount: item.price * item.qty,
        qty: item.qty,
        unitPrice: item.price,
        timestamp: new Date().toISOString()
      });
    });

    try {
      await update(ref(db), updates);
      
      // Push each ledger entry
      for (const entry of ledgerEntries) {
        await push(ref(db, 'ledger'), entry);
      }

      // Save Order
      const currentInvoice = {
        orderId,
        date: new Date().toLocaleString(),
        customer: customerInfo,
        items: cart,
        cartTotal,
        gst,
        deliveryCharge,
        grandTotal,
        vehicle,
        dispatchAgent: vehicle === "Bike" ? "Raju (9898098980)" : "Amit (7676076760)"
      };

      await push(ref(db, 'orders'), currentInvoice);
      setInvoiceData(currentInvoice);
      setShowInvoice(true);
      setCart([]);
      
    } catch (e) {
      alert("Error processing checkout: " + e.message);
    }
  };

  if (showInvoice && invoiceData) {
    return (
      <div className="main-content animate-fade-in">
        <div className="glass-card receipt-modal max-w-2xl mx-auto">
          <div className="text-center mb-6">
            <h2 className="text-primary font-bold">OFFICIAL INVOICE</h2>
            <p>TECHNO TRADER</p>
          </div>
          
          <div className="grid-cols-2 mb-6">
            <div>
              <p><strong>Order ID:</strong> {invoiceData.orderId}</p>
              <p><strong>Date:</strong> {invoiceData.date}</p>
            </div>
            <div className="text-right">
              <p><strong>Customer:</strong> {invoiceData.customer.name}</p>
              <p><strong>Mo:</strong> {invoiceData.customer.mobile}</p>
              <p><strong>Address:</strong> {invoiceData.customer.address}</p>
            </div>
          </div>
          
          <table className="mb-6">
            <thead>
              <tr>
                <th>Item</th>
                <th>Qty</th>
                <th className="text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {invoiceData.items.map((item, idx) => (
                <tr key={idx}>
                  <td>{item.name}</td>
                  <td>{item.qty}</td>
                  <td className="text-right">Rs. {(item.price * item.qty).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          
          <div className="flex justify-between border-t border-gray-700 pt-4 mb-2">
            <span>Sub Total:</span>
            <span>Rs. {invoiceData.cartTotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span>GST (18%):</span>
            <span>Rs. {invoiceData.gst.toFixed(2)}</span>
          </div>
          <div className="flex justify-between mb-4 pb-4 border-b border-gray-700">
            <span>Delivery ({invoiceData.vehicle}):</span>
            <span>Rs. {invoiceData.deliveryCharge.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-xl font-bold text-success mb-6">
            <span>GRAND TOTAL:</span>
            <span>Rs. {invoiceData.grandTotal.toFixed(2)}</span>
          </div>
          
          <div className="bg-slate-800 p-4 rounded-lg mb-6">
            <h4 className="flex items-center gap-2 mb-2"><Truck size={18} /> Dispatch Details</h4>
            <p>Vehicle: {invoiceData.vehicle}</p>
            <p>Agent: {invoiceData.dispatchAgent}</p>
          </div>
          
          <p className="text-center text-sm text-secondary mb-6">Guarantee And Warranty Are Applicable as per Company Policy.<br/>Thank You For Shopping With Techno Trader!</p>
          
          <button className="btn btn-primary w-full" onClick={() => setShowInvoice(false)}>Return to Shop</button>
        </div>
      </div>
    );
  }

  return (
    <div className="main-content">
      <div className="flex gap-8">
        
        {/* Left Side: Product Catalog */}
        <div className="flex-1">
          <h2 className="flex items-center gap-2 mb-6"><Package /> Electronics Catalog</h2>
          <div className="grid-cols-2 lg:grid-cols-3 mb-8">
            {inventory.map(product => (
              <div key={product.id} className="glass-card flex flex-col justify-between">
                <div>
                  <div className="product-image-container mb-4 text-primary">
                    <Package size={48} />
                  </div>
                  <h3 className="text-lg">{product.name}</h3>
                  <div className="flex justify-between items-center mt-2 mb-4">
                    <span className="font-bold text-xl">Rs. {product.price}</span>
                    {product.stock > 0 ? (
                      <span className="badge badge-success">{product.stock} Available</span>
                    ) : (
                      <span className="badge badge-danger">Out of Stock</span>
                    )}
                  </div>
                </div>
                <button 
                  className={`btn ${product.stock > 0 ? 'btn-primary' : 'btn-outline'} w-full mt-auto`}
                  onClick={() => addToCart(product)}
                  disabled={product.stock <= 0}
                >
                  {product.stock > 0 ? "Add to Cart" : "Unavailable"}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Right Side: Cart & Details */}
        <div className="w-96 shrink-0">
          <div className="glass-card mb-6 sticky top-24">
            <h3 className="flex items-center gap-2 mb-4"><User size={20}/> Customer Details</h3>
            <div className="form-group">
              <input type="text" className="form-input" placeholder="Full Name" value={customerInfo.name} onChange={e => setCustomerInfo({...customerInfo, name: e.target.value})} />
            </div>
            <div className="form-group">
              <input type="text" className="form-input" placeholder="Mobile (10 digits)" maxLength="10" value={customerInfo.mobile} onChange={e => setCustomerInfo({...customerInfo, mobile: e.target.value.replace(/\D/g, '')})} />
            </div>
            <div className="form-group">
              <textarea className="form-input" placeholder="Delivery Address" rows="2" value={customerInfo.address} onChange={e => setCustomerInfo({...customerInfo, address: e.target.value})}></textarea>
            </div>

            <h3 className="flex items-center gap-2 mb-4 mt-8"><ShoppingCart size={20}/> Your Cart</h3>
            {cart.length === 0 ? (
              <p className="text-secondary italic text-center py-4">Cart is empty</p>
            ) : (
              <>
                <div className="max-h-60 overflow-y-auto mb-4 pr-2">
                  {cart.map(item => (
                    <div key={item.id} className="flex justify-between items-center mb-3 text-sm border-b border-gray-700 pb-2">
                      <div>
                        <div className="font-bold">{item.name}</div>
                        <div className="text-secondary">{item.qty} x Rs.{item.price}</div>
                      </div>
                      <div className="font-bold">Rs. {item.qty * item.price}</div>
                    </div>
                  ))}
                </div>
                
                <div className="bg-slate-800 p-3 rounded-lg mb-4 text-sm">
                  <div className="flex justify-between mb-1"><span>Subtotal:</span><span>Rs. {cartTotal}</span></div>
                  <div className="flex justify-between mb-1"><span>GST (18%):</span><span>Rs. {gst.toFixed(2)}</span></div>
                  <div className="flex justify-between mb-1 text-info"><span>Delivery ({vehicle}):</span><span>Rs. {deliveryCharge}</span></div>
                  <div className="flex justify-between font-bold text-lg mt-2 pt-2 border-t border-gray-600">
                    <span>Total:</span><span className="text-success">Rs. {grandTotal.toFixed(2)}</span>
                  </div>
                </div>

                <button className="btn btn-success w-full flex items-center justify-center gap-2" onClick={handleCheckout}>
                  <ShieldCheck size={18} /> Checkout Securely
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerPortal;
