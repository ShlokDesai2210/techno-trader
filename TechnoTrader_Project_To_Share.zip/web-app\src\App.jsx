import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Package, ShieldAlert, MonitorPlay } from 'lucide-react';

import CustomerPortal from './components/CustomerPortal';
import AdminPortal from './components/AdminPortal';
import { seedDatabase } from './utils/seedData';
import { ref, get } from 'firebase/database';
import { db } from './firebase';

const NavBar = () => {
  const location = useLocation();
  return (
    <nav className="navbar">
      <Link to="/" className="nav-brand">
        <MonitorPlay size={28} /> TechnoTrader
      </Link>
      <div className="nav-links">
        <Link to="/" className={`nav-link flex items-center gap-2 ${location.pathname === '/' ? 'active' : ''}`}>
          <Package size={18} /> Shop Products
        </Link>
        <Link to="/admin" className={`nav-link flex items-center gap-2 ${location.pathname === '/admin' ? 'active' : ''}`}>
          <ShieldAlert size={18} /> Admin Panel
        </Link>
      </div>
    </nav>
  );
};

function App() {
  const [loading, setLoading] = useState(true);
  const [initError, setInitError] = useState(null);

  useEffect(() => {
    // Check if db is empty, if so, seed it
    const checkAndSeed = async () => {
      try {
        // Add a timeout so it doesn't hang forever
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error("Database connection timed out. Check your Firebase rules and config.")), 8000)
        );
        
        const invRef = ref(db, 'inventory');
        
        // Race the fetch against the timeout
        const snapshot = await Promise.race([get(invRef), timeoutPromise]);
        
        if (!snapshot.exists()) {
          console.log("Database is empty, seeding...");
          await Promise.race([seedDatabase(), timeoutPromise]);
        }
      } catch (e) {
        console.error("Database check error:", e);
        setInitError(e.message);
      } finally {
        setLoading(false);
      }
    };
    
    checkAndSeed();
  }, []);

  if (loading) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-slate-900 text-white">
        <div className="text-xl animate-pulse">Connecting to Firebase Realtime Database...</div>
      </div>
    );
  }

  if (initError) {
    return (
      <div className="flex flex-col h-screen w-screen items-center justify-center bg-slate-900 text-white p-6 text-center">
        <ShieldAlert size={64} className="text-red-500 mb-4" />
        <h2 className="text-2xl font-bold mb-2">Database Connection Error</h2>
        <p className="text-red-400 mb-4 max-w-lg">{initError}</p>
        <p className="text-gray-400">Please make sure you have created the Realtime Database in your Firebase Console and set the rules to "Test Mode" (allow read, write: if true).</p>
        <button onClick={() => window.location.reload()} className="mt-6 px-4 py-2 bg-indigo-600 rounded hover:bg-indigo-700 transition">Retry Connection</button>
      </div>
    );
  }

  return (
    <Router>
      <div className="app-container">
        <NavBar />
        <Routes>
          <Route path="/" element={<CustomerPortal />} />
          <Route path="/admin" element={<AdminPortal />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
